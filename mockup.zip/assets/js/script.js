$(document).ready(function() {
  $(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
$(function () {
  $('.example-popover').popover({
    container: 'body'
  })
})
});
